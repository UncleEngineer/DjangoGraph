from django import forms
from .models import ContactUs

class contact_form(forms.ModelForm):

	class Meta:
		model = ContactUs
		fields = ('name','email','category','topic','detail')